/*
 * ╔══════════════════════════════════════════════════════════════╗
 * ║   KapTester V2  —  Firmware 2: Testmodus                    ║
 * ║   ATmega328P-AU @ 16 MHz (externer Quarz)                   ║
 * ║   Autor: Nico Schmidt  |  AP2-Abschlussprojekt              ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * ── Zweck dieser Firmware ────────────────────────────────────────
 *   BEVOR die Produktions-Firmware geflasht wird, prüft diese
 *   Firmware JEDE EINZELNE Komponente der Platine auf Funktion.
 *   So kann man sicher sein, dass Hardware-Probleme nicht als
 *   Software-Bugs erscheinen.
 *
 *   Jeder Schritt wird durch Drücken von SW1 bestätigt.
 *   Das OLED zeigt IMMER an was gerade passiert und was erwartet wird.
 *
 * ── Testreihenfolge ──────────────────────────────────────────────
 *   00  INTRO         Startmeldung, Überblick
 *   01  LED GRÜN      Grüne LED D1 einschalten → Sichtprüfung
 *   02  LED ROT       Rote LED D2 einschalten  → Sichtprüfung
 *   03  BEIDE LEDs    Beide gleichzeitig       → Sichtprüfung
 *   04  OLED PIXEL    Alle Pixel an (Hellfeld) → tote Pixel erkennbar
 *   05  OLED FONT     Zeichensatz anzeigen     → Schrift prüfen
 *   06  BUTTON TEST   3× drücken zählen        → Taster + Firmware OK
 *   07  TP-ÜBERSICHT  Alle 4 Testpunkte mit Sollwerten (Multimeter!)
 *   08  ADC LIVE      JTP4 (MEAS_NODE) live via ATmega ADC messen
 *   09  AVCC MESSEN   Versorgungsspannung via Bandgap-Trick berechnen
 *   10  ENTLADE TEST  Q2 + R20 Entladepfad prüfen
 *   11  FERTIG        Alle Tests abgeschlossen
 *
 * ── Was sind Testpunkte (TPs)? ───────────────────────────────────
 *   Testpunkte = kleine Lötpads auf der Platine, an die man
 *   ein Multimeter-Prüfkabel anlegen kann.
 *   Sie erlauben das Messen von Spannungen an kritischen Stellen
 *   OHNE die Schaltung zu verändern.
 *
 *   JTP1  USB_5V      5 V direkt von USB vor Verpolschutz Q1
 *   JTP2  +5V_BOARD   5 V nach Q1 PMOS (= interne Versorgung)
 *   JTP3  LM317_OUT   Ausgang des LM317 (Konstantstrom-Quelle)
 *   JTP4  MEAS_NODE   Messknoten = DUT+ = was ADC0 misst
 *
 * ── Pin-Belegung (identisch zu FW1) ─────────────────────────────
 *   PD2  │ LED_PWR    │ Grüne LED D1, aktiv HIGH
 *   PD3  │ LED_ERR    │ Rote  LED D2, aktiv HIGH
 *   PB1  │ DISCH_GATE │ Gate Q2 (2N7002), HIGH = Entladen
 *   PC0  │ ADC_MEAS   │ MEAS_NODE = JTP4
 *   PC2  │ START_BTN  │ Taster SW1, Pull-Up, aktiv LOW
 *   PC4  │ I2C SDA    │ OLED SSD1306
 *   PC5  │ I2C SCL    │ OLED SSD1306
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>
#include "i2c.h"
#include "ssd1306.h"


/* ════════════════════════════════════════════════════════════════
 *  GPIO-MAKROS
 *  (identische Definitionen wie in FW1 — Makros statt magische Zahlen)
 * ════════════════════════════════════════════════════════════════ */
#define LED_GRN_ON()    (PORTD |=  (1<<PD2))
#define LED_GRN_OFF()   (PORTD &= ~(1<<PD2))
#define LED_RED_ON()    (PORTD |=  (1<<PD3))
#define LED_RED_OFF()   (PORTD &= ~(1<<PD3))
#define DISCH_ON()      (PORTB |=  (1<<PB1))  /* Q2 leitet: Entladen */
#define DISCH_OFF()     (PORTB &= ~(1<<PB1))  /* Q2 sperrt: Laden    */
#define BTN_PRESSED()   (!(PINC & (1<<PC2)))  /* true wenn Taster gedrückt */


/* ════════════════════════════════════════════════════════════════
 *  HARDWARE-INIT
 * ════════════════════════════════════════════════════════════════ */

static void gpio_init(void)
{
    /* PD2/PD3 = Ausgänge (LEDs), PB1 = Ausgang (Q2-Gate) */
    DDRD |=  (1<<PD2) | (1<<PD3);
    DDRB |=  (1<<PB1);

    /* PC2 (Taster) und PC0 (ADC) = Eingänge */
    DDRC &= ~((1<<PC2) | (1<<PC0));

    /* Pull-Up für Taster: ohne Pull-Up wäre der Pin "floating"
     * (undefiniertes Potenzial), wenn der Taster nicht gedrückt ist */
    PORTC |= (1<<PC2);

    /* ADC-Pin OHNE Pull-Up — würde Messung verfälschen */
    PORTC &= ~(1<<PC0);

    /* Sicherer Startzustand */
    LED_GRN_OFF();
    LED_RED_OFF();
    DISCH_OFF();  /* Q2 aus: kein ungewolltes Entladen */
}


/* ════════════════════════════════════════════════════════════════
 *  ADC-FUNKTIONEN
 *  Zwei verschiedene Betriebsmodi je nach Test:
 *    1. Interne 1,1-V-Referenz → für MEAS_NODE (JTP4) messen
 *    2. AVCC als Referenz      → für AVCC-Berechnung via Bandgap
 * ════════════════════════════════════════════════════════════════ */

/*
 * adc_init_internal — ADC mit interner 1,1-V-Referenz initialisieren
 *
 * ADMUX-Bits REFS1|REFS0 = 1|1 → interne 1,1-V-Bandgap-Referenz
 * Kanal 0 (MUX=0000) = Pin PC0 = MEAS_NODE = JTP4
 *
 * Prescaler 128: ADC-Takt = 16 MHz / 128 = 125 kHz
 * (ADC-Datenblatt: 50–200 kHz für volle 10-Bit-Auflösung)
 */
static void adc_init_internal(void)
{
    /* Interne 1,1-V-Ref, Kanal ADC0 */
    ADMUX  = (1<<REFS1) | (1<<REFS0);
    /* ADC ein, Prescaler 128 */
    ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0);
    /* Erste Wandlung verwerfen (Referenz schwingt ein) */
    ADCSRA |= (1<<ADSC);
    while (ADCSRA & (1<<ADSC));
}

/*
 * adc_set_avcc_ref — Umschalten auf AVCC als Referenz
 *
 * REFS0=1, REFS1=0 → AVCC als Referenz (typisch = 5 V)
 * Wird für den AVCC-Mess-Trick benötigt (Schritt 09).
 * Danach 10 ms warten: neue Referenz muss erst einschwingen.
 */
static void adc_set_avcc_ref(void)
{
    ADMUX  = (1<<REFS0);  /* AVCC als Referenz, kein REFS1 */
    ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0);
    _delay_ms(10);         /* Referenz stabilisieren */
    ADCSRA |= (1<<ADSC);
    while (ADCSRA & (1<<ADSC));
}

/*
 * adc_read_ch — Bestimmten ADC-Kanal lesen
 *
 * ch: Kanalnummer 0–15 (0 = PC0, 14 = interner Bandgap)
 * Die unteren 4 Bits von ADMUX wählen den Kanal.
 * Die oberen 4 Bits (Referenz-Auswahl) bleiben unverändert.
 */
static uint16_t adc_read_ch(uint8_t ch)
{
    /* Nur MUX-Bits (0-3) setzen, Referenzbits beibehalten */
    ADMUX = (ADMUX & 0xF0) | (ch & 0x0F);
    _delay_us(100);          /* Kurz warten: Eingangs-Multiplexer stabilisieren */
    ADCSRA |= (1<<ADSC);
    while (ADCSRA & (1<<ADSC));
    return ADC;
}

/*
 * measure_avcc_mv — AVCC-Spannung in mV berechnen
 *
 * ── Der Bandgap-Trick ────────────────────────────────────────────
 * Problem: Wir wollen AVCC messen, aber der ADC braucht eine
 * Referenzspannung. Wenn wir AVCC als Referenz setzen, können wir
 * AVCC nicht messen (man kann nichts mit sich selbst vergleichen).
 *
 * Lösung: Der ATmega hat eine INTERNE 1,1-V-Referenz (Bandgap).
 * Diese ist unabhängig von AVCC → wir können sie als "Maßstab" nutzen.
 *
 * Vorgehen:
 *   1. AVCC als ADC-Referenz setzen
 *   2. ADC-Kanal 14 messen = die interne 1,1-V-Referenz
 *   3. Ergebnis: ADC_bg = (1,1 V / AVCC) × 1023
 *   4. Umformen: AVCC = 1,1 V × 1023 / ADC_bg
 *
 * Beispiel:
 *   AVCC = 5,0 V → ADC_bg = (1,1 / 5,0) × 1023 = 225
 *   Zurückrechnen: AVCC = 1100 mV × 1023 / 225 = 5004 mV ≈ 5,0 V ✓
 *
 * Genauigkeit: ±3-5% (begrenzt durch 1,1-V-Referenz-Toleranz)
 */
static uint16_t measure_avcc_mv(void)
{
    adc_set_avcc_ref();        /* AVCC als Referenz */
    uint16_t adc_bg = adc_read_ch(14);  /* Kanal 14 = interner Bandgap */
    adc_init_internal();       /* Zurück auf 1,1-V-Ref für Folgemessungen */

    if (adc_bg == 0) return 0; /* Division durch 0 verhindern */

    /* AVCC [mV] = 1100 mV × 1023 / ADC_Bandgap */
    return (uint16_t)((uint32_t)1100UL * 1023UL / adc_bg);
}


/* ════════════════════════════════════════════════════════════════
 *  BUTTON-HILFSFUNKTIONEN
 * ════════════════════════════════════════════════════════════════ */

/*
 * wait_button_release — Warten bis Taster gedrückt UND losgelassen
 *
 * Ablauf:
 *   1. 30 ms warten (Prellen abklingen lassen)
 *   2. Warten bis Taster gedrückt
 *   3. 30 ms warten
 *   4. Warten bis Taster losgelassen
 *   5. 30 ms warten (Prellen beim Loslassen)
 *
 * Warum so aufwendig? Mechanische Taster "prellen" (bounce):
 * Ein einziges Drücken erzeugt physikalisch 5-50 ms lang
 * schnelle Ein/Aus-Wechsel. Ohne Entprellung würde die Firmware
 * mehrere Tastendrücke registrieren.
 */
static void wait_button_release(void)
{
    _delay_ms(30);
    while (!BTN_PRESSED());  /* Warten bis gedrückt */
    _delay_ms(30);
    while  (BTN_PRESSED());  /* Warten bis losgelassen */
    _delay_ms(30);
}

/*
 * wait_button_timeout — Auf Tastendruck warten, mit Zeitlimit
 *
 * Wartet maximal timeout_ms Millisekunden auf einen Tastendruck.
 * Rückgabe: 1 = Taste gedrückt, 0 = Timeout
 *
 * Wird im Button-Test (Schritt 06) genutzt um nicht ewig zu warten.
 */
static uint8_t wait_button_timeout(uint16_t timeout_ms)
{
    for (uint16_t i = 0; i < timeout_ms; i++) {
        _delay_ms(1);
        if (BTN_PRESSED()) {
            wait_button_release();
            return 1;  /* Taste wurde gedrückt */
        }
    }
    return 0;  /* Timeout abgelaufen ohne Tastendruck */
}


/* ════════════════════════════════════════════════════════════════
 *  OLED PIXEL-TEST HILFSFUNKTIONEN
 * ════════════════════════════════════════════════════════════════ */

/*
 * oled_all_on — Alle OLED-Pixel einschalten (Hellfeld)
 *
 * SSD1306-Befehl 0xA5 = "DISPLAY ALL ON":
 * Ignoriert den RAM-Inhalt und schaltet alle Pixel ein.
 * → Dunkle Bereiche = kaputte Pixel = Produktionsfehler sichtbar.
 *
 * Dieser Befehl ändert NICHT den RAM-Inhalt.
 * Nach oled_normal() wird wieder normaler RAM-Inhalt angezeigt.
 */
static void oled_all_on(void)
{
    /* Direkt I2C-Befehl senden (umgeht ssd1306-Abstraktionsschicht) */
    i2c_start((SSD1306_ADDR << 1) | 0); /* Write-Modus */
    i2c_write(0x00);   /* Control-Byte: nächstes Byte = Command */
    i2c_write(0xA5);   /* Command 0xA5 = Entire Display ON */
    i2c_stop();
}

/*
 * oled_normal — Zurück zum normalen Display-Modus (aus RAM)
 *
 * Befehl 0xA4 = "DISPLAY ON FROM RAM" (Standardmodus)
 */
static void oled_normal(void)
{
    i2c_start((SSD1306_ADDR << 1) | 0);
    i2c_write(0x00);
    i2c_write(0xA4);   /* Command 0xA4 = Normal Display */
    i2c_stop();
}


/* ════════════════════════════════════════════════════════════════
 *  TEST-SCHRITTE
 *  Jeder Schritt ist eine eigene Funktion:
 *    - Zeigt auf OLED was getestet wird
 *    - Führt den Test durch
 *    - Wartet auf Button-Druck zum Weiterschalten
 *    - Schaltet Hardware nach Test wieder aus
 * ════════════════════════════════════════════════════════════════ */

/* ── SCHRITT 00: INTRO ─────────────────────────────────────────── */
static void step_intro(void)
{
    /* Alle LEDs aus, kein Entladen: sicherer Startzustand */
    LED_GRN_OFF(); LED_RED_OFF(); DISCH_OFF();

    ssd1306_clear();
    ssd1306_print(0, 0, " KapTester V2");
    ssd1306_print(0, 1, "** TESTMODUS **");
    ssd1306_print(0, 3, "Testet alle");
    ssd1306_print(0, 4, "Komponenten der");
    ssd1306_print(0, 5, "Platine einzeln.");
    ssd1306_print(0, 7, "-> BUTTON: Start");

    wait_button_release();
}

/* ── SCHRITT 01: LED GRÜN ──────────────────────────────────────── */
static void step_led_green(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 1/10: LED GRN");
    ssd1306_print(0, 2, "Grune LED D1");
    ssd1306_print(0, 3, "soll LEUCHTEN.");
    ssd1306_print(0, 5, "Siehst du sie?");
    ssd1306_print(0, 6, "Nicht? -> Lotstelle");
    ssd1306_print(0, 7, "-> BUTTON: weiter");

    LED_GRN_ON();         /* D1 einschalten */
    wait_button_release();
    LED_GRN_OFF();        /* Sauber ausschalten vor nächstem Test */
}

/* ── SCHRITT 02: LED ROT ───────────────────────────────────────── */
static void step_led_red(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 2/10: LED ROT");
    ssd1306_print(0, 2, "Rote LED D2");
    ssd1306_print(0, 3, "soll LEUCHTEN.");
    ssd1306_print(0, 5, "Nicht? -> R_LED und");
    ssd1306_print(0, 6, "Lotstelle pruefen");
    ssd1306_print(0, 7, "-> BUTTON: weiter");

    LED_RED_ON();
    wait_button_release();
    LED_RED_OFF();
}

/* ── SCHRITT 03: BEIDE LEDs ────────────────────────────────────── */
static void step_led_both(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 3/10: BEIDE");
    ssd1306_print(0, 2, "Beide D1 + D2");
    ssd1306_print(0, 3, "sollen leuchten.");
    ssd1306_print(0, 5, "Test: Treiben beide");
    ssd1306_print(0, 6, "LED-Pins genug Strom?");
    ssd1306_print(0, 7, "-> BUTTON: weiter");

    LED_GRN_ON(); LED_RED_ON();
    wait_button_release();
    LED_GRN_OFF(); LED_RED_OFF();
}

/* ── SCHRITT 04: OLED PIXELTEST ────────────────────────────────── */
static void step_oled_pixel(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 4/10: OLED PIX");
    ssd1306_print(0, 2, "Alle Pixel werden");
    ssd1306_print(0, 3, "eingeschaltet.");
    ssd1306_print(0, 5, "Kein dunkler Fleck?");
    ssd1306_print(0, 6, "-> Alle Pixel OK");
    _delay_ms(1500);  /* 1,5 s Hinweis lesen, dann Hellfeld */

    oled_all_on();    /* ALLE Pixel an → Sichtprüfung auf tote Pixel */
    wait_button_release();

    oled_normal();    /* Zurück zu normalem RAM-Modus */
}

/* ── SCHRITT 05: OLED ZEICHENSATZ ──────────────────────────────── */
static void step_oled_font(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 5/10: FONT");
    /* Vollständiger Zeichensatz: Ziffern, Groß- und Kleinbuchstaben */
    ssd1306_print(0, 2, "0123456789");
    ssd1306_print(0, 3, "ABCDEFGHIJKLMNO");
    ssd1306_print(0, 4, "PQRSTUVWXYZ");
    ssd1306_print(0, 5, "abcdefghijklmno");
    ssd1306_print(0, 6, "pqrstuvwxyz");
    ssd1306_print(0, 7, "-> BUTTON: weiter");
    /* Prüfen: Sind alle Zeichen klar lesbar? Fehlende Pixel? */
    wait_button_release();
}

/* ── SCHRITT 06: BUTTON-TEST ───────────────────────────────────── */
static void step_button_test(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 6/10: BUTTON");
    ssd1306_print(0, 2, "Druecke den");
    ssd1306_print(0, 3, "Button 3 mal!");
    ssd1306_print(0, 5, "Zaehler:");

    uint8_t count = 0;

    while (count < 3) {
        /* Aktuellen Zählerstand anzeigen */
        char buf[10];
        sprintf(buf, "%u / 3  ", count); /* Leerzeichen überschreiben alten Wert */
        ssd1306_print(9, 5, buf);

        /* Auf nächsten Tastendruck warten (max. 15 Sekunden) */
        if (!wait_button_timeout(15000)) {
            /* Timeout: 15 s kein Tastendruck */
            ssd1306_print(0, 7, "TIMEOUT! -> weiter");
            _delay_ms(1500);
            return; /* Schritt abbrechen, weiter mit nächstem */
        }
        count++;
    }

    /* Alle 3 Drücke erfolgreich gezählt */
    ssd1306_print(0, 7, "BUTTON: OK!     ");
    LED_GRN_ON(); _delay_ms(600); LED_GRN_OFF();
    _delay_ms(400);
}

/* ── SCHRITT 07: TESTPUNKT-ÜBERSICHT ───────────────────────────── */
/*
 * Zeigt alle 4 Testpunkte mit ihren SOLLWERTEN an.
 * JTP1–JTP3 sind NICHT direkt mit dem ATmega verbunden
 * → nur Multimeter-Messung möglich, Firmware zeigt nur Hinweise.
 * JTP4 (MEAS_NODE) wird im nächsten Schritt live gemessen.
 *
 * Erwartete Werte (ohne DUT angeschlossen, Gerät an USB):
 *   JTP1  USB_5V    : 4,75–5,25 V (USB-Toleranz ±5%)
 *   JTP2  +5V_BOARD : JTP1 - VGS_Q1 ≈ 4,9–5,0 V (PMOS fast verlustfrei)
 *   JTP3  LM317_OUT : bei offenem MEAS_NODE → nahe +5V_BOARD
 *                     mit 100µF DUT: fällt linear ab während Laden
 *   JTP4  MEAS_NODE : 0 V (offen, Q2 aus, kein DUT) → ADC ≈ 0
 */
static void step_tp_overview(void)
{
    /* ── Seite 1: JTP1 und JTP2 ── */
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 7/10: TESTPKT");
    ssd1306_print(0, 1, "Multimeter anlegen!");
    ssd1306_print(0, 3, "JTP1 USB_5V");
    ssd1306_print(0, 4, "  Soll: 4.75-5.25V");
    ssd1306_print(0, 5, "JTP2 +5V_BOARD");
    ssd1306_print(0, 6, "  Soll: ~5.0V");
    ssd1306_print(0, 7, "-> BUTTON: weiter");
    wait_button_release();

    /* ── Seite 2: JTP3 ── */
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 7/10: TESTPKT");
    ssd1306_print(0, 2, "JTP3 LM317_OUT");
    ssd1306_print(0, 3, "Soll ohne DUT:");
    ssd1306_print(0, 4, "  ~+5V_BOARD");
    ssd1306_print(0, 5, "Mit DUT + Laden:");
    ssd1306_print(0, 6, "  Faellt auf 0V ab");
    ssd1306_print(0, 7, "-> BUTTON: weiter");
    wait_button_release();

    /* ── Seite 3: JTP4 Ankündigung ── */
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 7/10: TESTPKT");
    ssd1306_print(0, 2, "JTP4 MEAS_NODE");
    ssd1306_print(0, 3, "= ATmega ADC0");
    ssd1306_print(0, 4, "Soll offen: ~0mV");
    ssd1306_print(0, 5, "Max messbar: 1100mV");
    ssd1306_print(0, 6, "(interne 1.1V Ref)");
    ssd1306_print(0, 7, "-> BUTTON: live ADC");
    wait_button_release();
}

/* ── SCHRITT 08: ADC LIVE (JTP4 = MEAS_NODE) ──────────────────── */
/*
 * Zeigt die Spannung am MEAS_NODE (JTP4) live auf dem OLED.
 * Der ATmega misst hier über ADC0 (PC0).
 *
 * Interne 1,1-V-Referenz: max. messbare Spannung = 1,1 V
 * Spannung [mV] = ADC-Wert × 1100 mV / 1023
 *
 * Testmöglichkeiten:
 *   - Offen (kein DUT): ≈ 0 mV (ADC liest ~0)
 *   - GND anlegen:        0 mV genau
 *   - 1,0 V anlegen:   ~1000 mV
 *   - 1,1 V anlegen:   ~1100 mV (ADC = 1023 = Maximum)
 *   - >1,1 V anlegen:  ADC bleibt bei 1023 (clipping)
 *   - Kondensator: lädt sich auf und ADC-Wert steigt live an
 *
 * Mittelwert aus 8 Messungen für stabilere Anzeige
 * (reduziert Rauschen durch Mittelung)
 */
static void step_adc_live(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 8/10: JTP4 ADC");
    ssd1306_print(0, 2, "MEAS_NODE live:");
    ssd1306_print(0, 4, "Offen   -> ~0 mV");
    ssd1306_print(0, 5, "Max ADC -> 1100 mV");
    ssd1306_print(0, 6, "Kondensator laden?");
    ssd1306_print(0, 7, "-> BUTTON: beenden");

    /* Live-Schleife: läuft bis Button gedrückt */
    for (;;) {
        /* 8 Messungen aufaddieren und mitteln (Rauschreduktion) */
        uint16_t raw_sum = 0;
        for (uint8_t k = 0; k < 8; k++) {
            ADCSRA |= (1<<ADSC);
            while (ADCSRA & (1<<ADSC));
            raw_sum += ADC;
        }
        uint16_t raw = raw_sum / 8;

        /* Rohe ADC-Zahl (0–1023) in Millivolt umrechnen:
         * U [mV] = raw × U_ref [mV] / ADC_max
         *        = raw × 1100 / 1023                  */
        uint16_t u_mv = (uint16_t)((uint32_t)raw * 1100UL / 1023UL);

        /* Ergebnis anzeigen (Zeile 3 wird immer überschrieben) */
        char buf[22];
        sprintf(buf, "U=%4u mV  raw=%4u", u_mv, raw);
        ssd1306_print(0, 3, buf);

        _delay_ms(150);  /* 150 ms zwischen Updates: stabile Anzeige */

        /* Button-Check ohne Warten (non-blocking) */
        if (BTN_PRESSED()) {
            wait_button_release();
            return;  /* Schritt beenden */
        }
    }
}

/* ── SCHRITT 09: AVCC MESSEN ───────────────────────────────────── */
/*
 * Misst die Versorgungsspannung AVCC via Bandgap-Trick.
 * Details zum Verfahren: siehe measure_avcc_mv() weiter oben.
 *
 * Erwarteter Wert: 4750–5250 mV (USB 5V ± 5%)
 * Prüft ob die Stromversorgung (USB → Q1 → +5V_BOARD) korrekt funktioniert.
 */
static void step_avcc(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 9/10: AVCC");
    ssd1306_print(0, 2, "Messe AVCC via");
    ssd1306_print(0, 3, "Bandgap-Methode...");
    ssd1306_print(0, 4, "(ATmega intern)");
    _delay_ms(500);

    /* Messung durchführen (dauert ~30 ms durch Referenz-Wartezeit) */
    uint16_t avcc = measure_avcc_mv();

    char buf[22];
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 9/10: AVCC");

    if (avcc > 4500 && avcc < 5500) {
        /* Spannung im normalen USB-Bereich: OK */
        sprintf(buf, "AVCC = %u mV", avcc);
        ssd1306_print(0, 2, buf);
        ssd1306_print(0, 3, "Soll: 4750-5250 mV");
        ssd1306_print(0, 4, "Ergebnis: OK");
        ssd1306_print(0, 5, "(USB-Spannung gut)");
    } else {
        /* Unerwarteter Wert: USB-Kabel, Q1 oder USB-Port prüfen */
        sprintf(buf, "AVCC = %u mV !!!", avcc);
        ssd1306_print(0, 2, buf);
        ssd1306_print(0, 3, "Soll: 4750-5250 mV");
        ssd1306_print(0, 4, "Pruefen: USB-Kabel");
        ssd1306_print(0, 5, "Q1 PMOS, USB-Port");
    }

    ssd1306_print(0, 7, "-> BUTTON: weiter");
    wait_button_release();
}

/* ── SCHRITT 10: ENTLADE-TEST ──────────────────────────────────── */
/*
 * Testet den Entladepfad: Q2 (2N7002 NMOS) + R20 (470 Ω).
 *
 * Ablauf:
 *   1. DISCH_GATE HIGH setzen → PB1 HIGH → Q2 Gate auf HIGH
 *   2. Q2 leitet jetzt: MEAS_NODE → R20 → Q2 (D→S) → GND
 *   3. MEAS_NODE sollte auf ~0 V fallen (kein DUT = kein Kondensator)
 *
 * Erwartete Werte:
 *   Kein DUT: MEAS_NODE direkt auf GND durch R20+Q2 → ~0 mV
 *   Mit DUT (geladener Kondensator): sinkt je nach C von V_initial auf 0 V
 *
 * Warum R20 (470 Ω) im Entladepfad?
 *   Ohne R20 würde ein großer geladener Elko (z.B. 10.000 µF bei 1 V)
 *   einen Impulsstrom treiben: I = V/R_intern ≈ sehr groß → Q2 könnte sterben.
 *   R20 begrenzt den Strom auf max. 1V / 470Ω ≈ 2 mA → sicher für Q2.
 */
static void step_disch_test(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 10/10:DISCH");
    ssd1306_print(0, 2, "Testet: Q2 + R20");
    ssd1306_print(0, 3, "Kein DUT! PB1 HIGH");
    ssd1306_print(0, 4, "-> Q2 leitet");
    ssd1306_print(0, 5, "MEAS_NODE -> GND");
    ssd1306_print(0, 6, "Soll: < 100 mV");
    _delay_ms(1500);  /* Nutzer liest Hinweis */

    /* Entladepfad aktivieren */
    DISCH_ON();
    _delay_ms(100);  /* Q2 leitet, Spannung fällt ab */

    /* ADC-Wert lesen: sollte nahe 0 sein */
    ADCSRA |= (1<<ADSC);
    while (ADCSRA & (1<<ADSC));
    uint16_t raw = ADC;
    uint16_t u_mv = (uint16_t)((uint32_t)raw * 1100UL / 1023UL);

    /* Ergebnis anzeigen */
    char buf[22];
    ssd1306_clear();
    ssd1306_print(0, 0, "TEST 10/10:DISCH");
    ssd1306_print(0, 2, "DISCH_GATE: HIGH");
    ssd1306_print(0, 3, "Q2 leitet gerade");

    sprintf(buf, "JTP4: %u mV", u_mv);
    ssd1306_print(0, 5, buf);
    ssd1306_print(0, 6, "Soll: < 100 mV");

    if (u_mv < 100) {
        ssd1306_print(0, 7, "Ergebnis: OK");
        LED_GRN_ON(); _delay_ms(400); LED_GRN_OFF();
    } else {
        /* Spannung zu hoch: Q2 schaltet vielleicht nicht durch */
        ssd1306_print(0, 7, "Pruefen: Q2, R9,R20");
        led_blink: /* Goto-Label nicht verwenden in C - einfach blinken */
        LED_RED_ON(); _delay_ms(400); LED_RED_OFF();
    }

    DISCH_OFF();  /* WICHTIG: Entladung wieder deaktivieren! */

    /* Wait (Nutzer liest Ergebnis) dann Button zum Weiterschalten */
    _delay_ms(500);
    ssd1306_print(0, 7, "-> BUTTON: weiter");
    wait_button_release();
}

/* ── SCHRITT 11: FERTIG ────────────────────────────────────────── */
static void step_done(void)
{
    LED_GRN_ON();
    ssd1306_clear();
    ssd1306_print(0, 0, " KapTester V2");
    ssd1306_print(0, 2, "ALLE TESTS");
    ssd1306_print(0, 3, "ABGESCHLOSSEN!");
    ssd1306_print(0, 5, "Naechster Schritt:");
    ssd1306_print(0, 6, "FW1 flashen und");
    ssd1306_print(0, 7, "messen! Reset=neu");

    /* Kurze Blink-Sequenz als Abschluss-Signal */
    for (uint8_t i = 0; i < 3; i++) {
        LED_GRN_OFF(); _delay_ms(150);
        LED_GRN_ON();  _delay_ms(150);
    }

    /* Programm "einfrieren" → nur Reset startet neu
     * (kein weiterer Code nach allen Tests nötig) */
    for (;;) _delay_ms(1000);
}


/* ════════════════════════════════════════════════════════════════
 *  MAIN — Hauptprogramm
 *
 *  Ruft alle Test-Schritte nacheinander auf.
 *  Jede step_xxx() Funktion kehrt erst zurück wenn Button gedrückt.
 *  So ist die Reihenfolge linear und leicht zu lesen.
 * ════════════════════════════════════════════════════════════════ */
int main(void)
{
    gpio_init();         /* GPIO konfigurieren                     */
    adc_init_internal(); /* ADC mit 1,1-V-Ref initialisieren      */
    i2c_init();          /* I2C-Bus für OLED aktivieren            */
    ssd1306_init();      /* OLED Display initialisieren + löschen  */
    /* Kein sei() hier nötig: Testmodus nutzt keine Timer-Interrupts */

    /* Test-Schritte in Reihenfolge */
    step_intro();          /* 00: Begrüßung + Überblick   */
    step_led_green();      /* 01: Grüne LED testen        */
    step_led_red();        /* 02: Rote LED testen         */
    step_led_both();       /* 03: Beide LEDs testen       */
    step_oled_pixel();     /* 04: OLED Pixel-Test         */
    step_oled_font();      /* 05: OLED Zeichensatz        */
    step_button_test();    /* 06: Button 3× zählen        */
    step_tp_overview();    /* 07: Testpunkt-Übersicht     */
    step_adc_live();       /* 08: JTP4 live messen        */
    step_avcc();           /* 09: AVCC via Bandgap        */
    step_disch_test();     /* 10: Entladepfad testen      */
    step_done();           /* 11: Abschluss               */

    /* Hier wird nie angekommen (step_done friert ein) */
}
