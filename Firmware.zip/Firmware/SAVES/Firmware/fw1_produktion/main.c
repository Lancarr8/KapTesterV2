/*
 * ╔══════════════════════════════════════════════════════════════╗
 * ║   KapTester V2  —  Firmware 1: Produktion (Fix v2)          ║
 * ║   ATmega328P-AU @ 16 MHz (externer Quarz)                   ║
 * ║   Autor: Nico Schmidt  |  AP2-Abschlussprojekt              ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * ── Änderung gegenüber v1 ────────────────────────────────────────
 *   Problem: R20 (470 Ω) im Entladepfad → Gleichgewicht bei ~0,5 V.
 *   discharge_wait() erreichte nie ADC < 5 → 5000 ms Timeout.
 *   Nach DISCH_OFF lud LM317 den Cap sofort auf 1,1 V → 7 Ticks → 106 nF.
 *
 *   Fix 1: Entlade-Schwelle von < 5 auf < 470 (≈ 0,5 V) geändert.
 *          Schleife bricht ab wenn Gleichgewicht erreicht ist (~37 ms).
 *   Fix 2: _delay_ms(50) entfernt → Cap bleibt bei ~0,5 V.
 *   Fix 3: U_start direkt nach DISCH_OFF messen.
 *          Formel: C = I × t / (U_ref − U_start)
 *          Damit wird die Startspannung kompensiert → korrekte Werte.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include "i2c.h"
#include "ssd1306.h"

/* ════════════════════════════════════════════════════════════════
 *  KONSTANTEN
 * ════════════════════════════════════════════════════════════════ */
#define I_UA              1042UL   /* LM317L-Strom: 1,25V / 1200Ω = 1,042 mA */
#define U_REF_MV          1100UL   /* Interne 1,1-V-Bandgap-Referenz in mV    */
#define TICK_US             16UL   /* Timer1 Prescaler 256 → 16 µs/Tick       */
#define ADC_THRESH          1020   /* Ladeende: ~1,1 V (0,3 % vor Vollschlag) */
#define TIMEOUT_OVF         300U   /* ~314 s Timeout (300 × 65536 × 16 µs)    */
#define DISCH_TIMEOUT_MS   5000U   /* Max. Entladezeit in ms                  */
#define N_MEAS                3    /* Einzelmessungen pro Zyklus              */
#define PLAUS_PCT            15UL  /* Plausibilitätsgrenze ±15 %              */
#define CAP_MIN_NF        10000UL  /* 10 µF Untergrenze in nF                 */
#define CAP_MAX_NF     10000000UL  /* 10.000 µF Obergrenze in nF              */
#define BLINK_CYCLES        500U   /* ADC-Zyklen pro LED-Toggle               */

/*
 * DISCH_ADC_THRESH — Entlade-Schwelle (NEU, war 5):
 * R20 (470 Ω) im Entladepfad → Gleichgewicht bei I × R = 1,042 mA × 470 Ω ≈ 490 mV.
 * 490 mV / 1100 mV × 1023 ≈ 456 ADC-Counts → Schwelle 470 mit Puffer.
 * Schleife bricht ab sobald Cap das Gleichgewicht erreicht (~0,5 V).
 */
#define DISCH_ADC_THRESH    470

/*
 * U_START_MIN_MV — Mindest-Delta für gültige U_start-Messung.
 * Wenn Cap nach Entladen zu nahe an 1,1 V ist (< 50 mV Abstand),
 * wäre die Messung zu ungenau → Timeout zurückgeben.
 */
#define U_START_MIN_MV       50UL

/* ════════════════════════════════════════════════════════════════
 *  GPIO-MAKROS
 * ════════════════════════════════════════════════════════════════ */
#define LED_GRN_ON()    (PORTD |=  (1<<PD2))
#define LED_GRN_OFF()   (PORTD &= ~(1<<PD2))
#define LED_GRN_TOG()   (PORTD ^=  (1<<PD2))
#define LED_RED_ON()    (PORTD |=  (1<<PD3))
#define LED_RED_OFF()   (PORTD &= ~(1<<PD3))
#define DISCH_ON()      (PORTB |=  (1<<PB1))
#define DISCH_OFF()     (PORTB &= ~(1<<PB1))
#define BTN_PRESSED()   (!(PINC & (1<<PC2)))

/* ════════════════════════════════════════════════════════════════
 *  TIMER1 ISR
 * ════════════════════════════════════════════════════════════════ */
volatile uint16_t ovf_count = 0;
volatile uint8_t  ovf_flag  = 0;

ISR(TIMER1_OVF_vect)
{
    if (++ovf_count >= TIMEOUT_OVF)
        ovf_flag = 1;
}

/* ════════════════════════════════════════════════════════════════
 *  HARDWARE-INIT
 * ════════════════════════════════════════════════════════════════ */
static void gpio_init(void)
{
    DDRD |= (1<<PD2) | (1<<PD3);
    DDRB |= (1<<PB1);
    DDRC &= ~((1<<PC2) | (1<<PC0));
    PORTC |=  (1<<PC2);
    PORTC &= ~(1<<PC0);
    LED_GRN_OFF();
    LED_RED_OFF();
    DISCH_OFF();
}

static void adc_init(void)
{
    ADMUX  = (1<<REFS1) | (1<<REFS0);
    ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0);
    ADCSRA |= (1<<ADSC);
    while (ADCSRA & (1<<ADSC));
}

static uint16_t adc_read(void)
{
    ADCSRA |= (1<<ADSC);
    while (ADCSRA & (1<<ADSC));
    return ADC;
}

static void timer1_start(void)
{
    ovf_count = 0;
    ovf_flag  = 0;
    TCNT1     = 0;
    TIFR1    |= (1<<TOV1);
    TIMSK1    = (1<<TOIE1);
    TCCR1A    = 0;
    TCCR1B    = (1<<CS12);
}

static uint32_t timer1_stop(void)
{
    uint16_t cnt = TCNT1;
    TCCR1B = 0;
    TIMSK1 = 0;
    return (uint32_t)ovf_count * 65536UL + (uint32_t)cnt;
}

/* ════════════════════════════════════════════════════════════════
 *  ENTLADEN — FIX v2
 *
 *  NEU: Schwelle DISCH_ADC_THRESH (470) statt 5.
 *  Bricht ab wenn Cap das Gleichgewicht von ~0,5 V erreicht
 *  (≈ 37 ms für 100 µF statt 5000 ms Timeout).
 *
 *  NEU: Kein _delay_ms(50) mehr nach DISCH_OFF.
 *  Grund: Die 50 ms luden den Cap von 0,5 V auf ~1,1 V vor,
 *  was zu falschen Messwerten führte.
 *  Stattdessen: U_start direkt in single_measure() messen.
 * ════════════════════════════════════════════════════════════════ */
static void discharge_wait(void)
{
    DISCH_ON();

    for (uint16_t i = 0; i < DISCH_TIMEOUT_MS; i++) {
        _delay_ms(1);
        if (adc_read() < DISCH_ADC_THRESH) break;  /* ~0,5 V erreicht */
    }

    DISCH_OFF();
    /* Kein delay hier — U_start wird sofort in single_measure() gemessen */
}

/* ════════════════════════════════════════════════════════════════
 *  EINZELMESSUNG — FIX v2
 *
 *  NEU: U_start-Korrektur in der Formel.
 *
 *  Alt: C = I × t / U_REF_MV
 *       → Falsch wenn Cap nicht bei 0 V startet
 *
 *  Neu: C = I × t / (U_REF_MV − U_start_mV)
 *       → Korrekt unabhängig von der Startspannung
 *
 *  U_start wird direkt nach DISCH_OFF gemessen (Cap noch bei ~0,5 V,
 *  bevor LM317 nennenswert vorladen kann).
 * ════════════════════════════════════════════════════════════════ */
static uint32_t single_measure(void)
{
    discharge_wait();

    /*
     * Startspannung messen — sofort nach DISCH_OFF.
     * Eine ADC-Wandlung dauert ~104 µs, in der Zeit lädt LM317
     * maximal 104 µs × 1,042 mA / 100 µF ≈ 1 mV → vernachlässigbar.
     */
    uint16_t u_start_adc = adc_read();
    uint32_t u_start_mv  = (uint32_t)u_start_adc * U_REF_MV / 1023UL;
    uint32_t u_delta_mv  = U_REF_MV - u_start_mv;

    /*
     * Schutz: Cap zu nahe an der Messschwelle → Delta zu klein
     * für eine genaue Messung → Timeout-Wert zurückgeben.
     */
    if (u_delta_mv < U_START_MIN_MV)
        return 0;

    uint16_t adc_val   = 0;
    uint16_t blink_cnt = 0;

    timer1_start();

    do {
        adc_val = adc_read();

        if (++blink_cnt >= BLINK_CYCLES) {
            LED_GRN_TOG();
            blink_cnt = 0;
        }

        if (ovf_flag) break;

    } while (adc_val < ADC_THRESH);

    uint32_t ticks = timer1_stop();
    LED_GRN_OFF();

    if (ovf_flag || adc_val < ADC_THRESH)
        return 0;

    /*
     * C [nF] = I [µA] × TICK_US [µs] × ticks / (U_REF [mV] − U_start [mV])
     *
     * uint64_t für Zwischenwert nötig:
     * 1042 × 16 × 360.000 ≈ 6 Mrd. > uint32_t-Max (4,3 Mrd.)
     */
    uint64_t tmp = (uint64_t)I_UA * (uint64_t)TICK_US * (uint64_t)ticks;
    return (uint32_t)(tmp / u_delta_mv);
}

/* ════════════════════════════════════════════════════════════════
 *  PLAUSIBILITÄTSPRÜFUNG & MITTELWERT — unverändert
 * ════════════════════════════════════════════════════════════════ */
static uint8_t plausible_pair(uint32_t a, uint32_t b)
{
    uint32_t lo = (a < b) ? a : b;
    uint32_t hi = (a < b) ? b : a;
    return ((hi - lo) * 100UL) <= (PLAUS_PCT * lo);
}

static uint32_t evaluate(uint32_t v[3])
{
    uint8_t p01 = plausible_pair(v[0], v[1]);
    uint8_t p02 = plausible_pair(v[0], v[2]);
    uint8_t p12 = plausible_pair(v[1], v[2]);

    if (p01 && p02 && p12)   return (v[0]+v[1]+v[2]) / 3UL;
    if (p01 && !p12 && !p02) return (v[0]+v[1]) / 2UL;
    if (p02 && !p01 && !p12) return (v[0]+v[2]) / 2UL;
    if (p12 && !p01 && !p02) return (v[1]+v[2]) / 2UL;
    return 0;
}

/* ════════════════════════════════════════════════════════════════
 *  ERGEBNIS FORMATIEREN — unverändert
 * ════════════════════════════════════════════════════════════════ */
static void format_cap(uint32_t nf, char *buf)
{
    if (nf < 1000UL) {
        sprintf(buf, "%lu nF", nf);
    } else {
        uint32_t uf_int  = nf / 1000UL;
        uint32_t uf_frac = (nf % 1000UL) / 10UL;
        sprintf(buf, "%lu.%02lu uF", uf_int, uf_frac);
    }
}

static void led_blink_red(uint8_t times)
{
    for (uint8_t i = 0; i < times; i++) {
        LED_RED_ON();  _delay_ms(200);
        LED_RED_OFF(); _delay_ms(200);
    }
}

/* ════════════════════════════════════════════════════════════════
 *  OLED-SCREENS — unverändert
 * ════════════════════════════════════════════════════════════════ */
static void screen_boot(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, " KapTester V2");
    ssd1306_print(0, 2, "Hochfahren...");
    ssd1306_print(0, 4, "Initialisierung");
}

static void screen_ready(void)
{
    ssd1306_clear();
    ssd1306_print(0, 0, " KapTester V2");
    ssd1306_print(0, 2, "Status: Bereit");
    ssd1306_print(0, 4, "DUT anschliessen");
    ssd1306_print(0, 6, "START druecken");
}

static void screen_measuring(uint8_t n)
{
    char buf[20];
    ssd1306_clear();
    ssd1306_print(0, 0, " KapTester V2");
    sprintf(buf, "Messung %u / %u ...", n, N_MEAS);
    ssd1306_print(0, 3, buf);
    ssd1306_print(0, 5, "Bitte warten");
}

/* ════════════════════════════════════════════════════════════════
 *  MAIN — unverändert
 * ════════════════════════════════════════════════════════════════ */
int main(void)
{
    gpio_init();
    adc_init();
    i2c_init();
    ssd1306_init();
    sei();

    LED_RED_ON();
    screen_boot();
    _delay_ms(800);
    LED_RED_OFF();

    LED_GRN_ON();
    screen_ready();

    for (;;) {
        if (!BTN_PRESSED()) continue;
        _delay_ms(30);
        if (!BTN_PRESSED()) continue;
        while (BTN_PRESSED());

        LED_RED_OFF();

        uint32_t vals[N_MEAS];
        uint8_t  timeout_any = 0;

        for (uint8_t i = 0; i < N_MEAS; i++) {
            screen_measuring(i + 1);
            vals[i] = single_measure();

            if (vals[i] == 0) {
                timeout_any = 1;
                break;
            }
            _delay_ms(200);
        }

        if (timeout_any) {
            LED_GRN_OFF();
            ssd1306_clear();
            ssd1306_print(0, 1, "** TIMEOUT **");
            ssd1306_print(0, 3, "Kein DUT oder");
            ssd1306_print(0, 4, "< 10 uF erkannt");
            ssd1306_print(0, 6, "Polung pruefen!");
            led_blink_red(5);
            LED_RED_ON();
            _delay_ms(2000);
            LED_RED_OFF();
            discharge_wait();
            LED_GRN_ON();
            screen_ready();
            continue;
        }

        uint32_t result = evaluate(vals);

        if (result == 0) {
            LED_GRN_OFF();
            char b0[16], b1[16], b2[16];
            format_cap(vals[0], b0);
            format_cap(vals[1], b1);
            format_cap(vals[2], b2);
            ssd1306_clear();
            ssd1306_print(0, 0, "** FAIL **");
            ssd1306_print(0, 2, "Werte streuen:");
            ssd1306_print(0, 3, b0);
            ssd1306_print(0, 4, b1);
            ssd1306_print(0, 5, b2);
            ssd1306_print(0, 7, "Kontakt pruefen");
            led_blink_red(6);
            LED_RED_ON();
            _delay_ms(3000);
            LED_RED_OFF();
            discharge_wait();
            LED_GRN_ON();
            screen_ready();
            continue;
        }

        char cap_str[20];
        format_cap(result, cap_str);

        uint8_t out_of_range = 0;
        const char *range_warn = "";

        if (result < CAP_MIN_NF) {
            out_of_range = 1;
            range_warn   = "Warnung: < 10uF!";
        } else if (result > CAP_MAX_NF) {
            out_of_range = 1;
            range_warn   = "Warnung: > 10mF!";
        }

        ssd1306_clear();
        ssd1306_print(0, 0, " KapTester V2");
        ssd1306_print(0, 2, "Ergebnis:");
        ssd1306_print(0, 3, cap_str);

        if (out_of_range) {
            ssd1306_print(0, 5, range_warn);
            ssd1306_print(0, 6, "Ausserh. Bereich");
            LED_GRN_OFF();
            led_blink_red(3);
            LED_RED_ON();
        } else {
            ssd1306_print(0, 5, "Bereich: OK");
            LED_RED_OFF();
            LED_GRN_ON();
        }

        ssd1306_print(0, 7, "START=neu messen");

        _delay_ms(300);
        discharge_wait();

        LED_RED_OFF();
        LED_GRN_ON();
        screen_ready();
    }
}
